1. Przed rozpoczęciem testów w rozpakowanym katalogu se4t3 uruchom 
	./prepare.sh /tmp/Test
2. Po zakończeniu testów w te4t1 uruchom
	./clean.sh /tmp/Test
3. Do uruchomienia wszystkich testów służy run_all.sh. Przykładowe wywołanie
	./run_all.sh ~/shell/mshell /tmp/Test
