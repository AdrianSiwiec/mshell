1. Przed rozpoczęciem testów w rozpakowanym katalogu test5 uruchom 
	./prepare.sh /tmp/Test
2. Po zakończeniu testów w test5 uruchom
	./clean.sh /tmp/Test
3. Do uruchomienia wszystkich testów służy run_all.sh. Przykładowe wywołanie
	./run_all.sh ~/shell/mshell /tmp/Test
