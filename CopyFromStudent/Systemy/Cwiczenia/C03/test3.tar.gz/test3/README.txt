1. Przed rozpoczęciem testów w rozpakowanym katalogu test3 uruchom 
	./prepare.sh /tmp/Test3
2. Po zakończeniu testów w test1 uruchom
	./clean.sh /tmp/Test3
3. Do uruchomienia wszystkich testów służy run_all.sh. Przykładowe wywołanie
	./run_all.sh ~/shell/mshell /tmp/Test1
